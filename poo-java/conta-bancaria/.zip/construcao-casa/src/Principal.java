import controle.Controladora;

public class Principal {

    public static void main(String[] args) {

        Controladora controller = new Controladora();

        controller.exibeMenu();

    }

}
