package modelo;

public class Multiplicacao extends Operacoes {

    @Override
    public double calcula() {
        return this.num1 * this.num2;
    }

}
