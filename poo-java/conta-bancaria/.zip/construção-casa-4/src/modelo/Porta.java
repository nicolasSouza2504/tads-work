package modelo;

public class Porta extends Aberturas {

}
