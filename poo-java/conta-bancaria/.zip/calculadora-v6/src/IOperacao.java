public interface IOperacao {

    double calcula();

}
