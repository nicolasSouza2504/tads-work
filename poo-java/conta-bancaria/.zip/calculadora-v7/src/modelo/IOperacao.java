package modelo;

public interface IOperacao {

    double calcula();

}
