import controller.Controller;

public class Principal {

    public static void main(String[] args) {

        Controller controller = new Controller();

        controller.exibirMenu();

    }

}
