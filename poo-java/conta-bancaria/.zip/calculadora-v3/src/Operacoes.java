public class Operacoes {

    public double calculaDivisao(double num1, double num2) {
        return num1 / num2;
    }

    public double calculaMultiplicacao(double num1, double num2) {
        return num1 * num2;
    }

    public double calculaSubtracao(double num1, double num2) {
        return num1 - num2;
    }

    public double calculaSoma(double num1, double num2) {
        return num1 + num2;
    }

}
