package modelo;

public class Casa extends Aberturas {
}
