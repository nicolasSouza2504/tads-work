public interface IOperacao {

    void setNum1(double num1);
    void setNum2(double num2);
    double calcula();

}
