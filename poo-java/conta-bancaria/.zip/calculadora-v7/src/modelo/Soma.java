package modelo;

public class Soma extends Operacoes {

    @Override
    public double calcula() {
        return super.num1 + super.num2;
    }

}
