import controle.Controladora;

public class Principal {

    public static void main(String[] args) throws Exception {

        Controladora controller = new Controladora();

        controller.exibeMenu();

    }

}
